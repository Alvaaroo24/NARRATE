# Third-party imports
import os

import requests
from sqlalchemy.orm import Session

def get_plugin_catalog(db: Session):
    """
    Returns the plugins catalog.
    """
    try:
        plugins = db.query(Plugin).all()

        decrypted_plugins = []
        for plugin in plugins:
            decrypted_plugin = {
                "id": plugin.id,
                "client_id": plugin.client_id,
                "domain_id": plugin.domain_id,
                "user_id": plugin.user_id,
                "url": plugin.url,
                "title": plugin.title,
                "description": plugin.description,
                "manifest_url": plugin.manifest_url,
                "auth_type": plugin.auth_type,
                "auth_params": (
                    EncryptDecrypt.decrypt_secret_key(
                        plugin.auth_params, os.getenv("ENCRYPT_SECRET_KEY")
                    )
                    if plugin.auth_params
                    else None
                ),
                "config_params": (
                    EncryptDecrypt.decrypt_secret_key(
                        plugin.config_params, os.getenv("ENCRYPT_SECRET_KEY")
                    )
                    if plugin.config_params
                    else None
                ),
                "prompt": plugin.prompt,
                "type": plugin.type,
                "subtype": plugin.subtype,
                "verify_ssl": plugin.verify_ssl,
            }
            decrypted_plugins.append(decrypted_plugin)

    except (Exception, psycopg2.Error) as e:
        logging.exception(e)
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error while searching plugin catalog",
        )

    if plugins is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No plugins found",
        )

    return decrypted_plugins