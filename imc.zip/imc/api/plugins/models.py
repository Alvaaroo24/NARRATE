
# Standard imports
from typing import Any, Dict, Optional

# Third party imports
from pydantic import BaseModel

class PluginCatalogResponse(BaseModel):
    """Pydantic model that represents the standard response structure for the plugin catalog process"""

    plugins: list[Any]
    


class PluginInfo(BaseModel):
    id: int
    url: Optional[str] = None
    title: str
    description: str
    schema_url: Optional[str] = None
    auth_type: Optional[str] = None
    auth_params: Optional[Any] = None
    config_params: Optional[Any] = None
    prompt: Optional[str] = None
    verify_ssl: bool