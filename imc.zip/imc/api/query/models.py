from typing import Any, Optional

from pydantic import BaseModel


class QueryInput(BaseModel):
    chat_id: int
    message_id: int
    query: str

class QueryResponse(BaseModel):
    response: Any
    