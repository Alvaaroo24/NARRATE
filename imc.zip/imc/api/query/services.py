from sqlalchemy.ext.asyncio import AsyncSession

from imc.api.query.models import QueryInput
from imc.modules.agents.utils.models import QueryResponse
from imc.modules.events.events import get_event_from_query
from imc.modules.data_managers.chat_manager import ChatManager
from imc.modules.data_managers.plan_manager import PlanManager
from imc.modules.data_managers.rules_manager import RulesManager
from imc.modules.agents.orchestrator.module import OrchestratorAgent


async def query(query_input: QueryInput, db: AsyncSession) -> QueryResponse:
    """"
    """
    event = get_event_from_query(query_input)

    chat_manager = ChatManager()
    plan_manager = PlanManager()
    rules_manager = RulesManager()

    orchestrator_agent = OrchestratorAgent(
        chat_manager=chat_manager,
        plan_manager=plan_manager,
        rules_manager=rules_manager
    )

    response = await orchestrator_agent.get_response(event, db)

    return response


