from imc.modules.events.models import EventModel, MessageModel
from imc.api.query.models import QueryInput


def get_event_from_query(query_input: QueryInput) -> EventModel:
    """
    """
    event_type = "chat_query" # TODO: Get event type in base of query
    event_model = EventModel(
        chat_id=query_input.chat_id,
        message_id=query_input.message_id,
        query=query_input.query,
        event_type=event_type
    )
    return event_model

def get_event_from_message(message: MessageModel) -> EventModel:
    """
    """
    # TODO: the chat_id and message_id will not be choose here
    event_model = EventModel(
        chat_id=1,
        message_id=1,
        query=message.alert,
        event_type=message.event_type
    )
    return event_model