
# Standard imports
from typing import Any, Dict, Optional

# Third party imports
from pydantic import BaseModel

class EventModel(BaseModel):
    chat_id: int
    message_id: int
    query: str
    event_type: str

class MessageModel(BaseModel):
    """
    Message model for the parsed rabbitMQ message:
        {
        "eventId": "11111",
        “eventType:” sensorAlert”
        "time": 1242352352352,
        "timeHR": "Mo 10:30:10, 05-10-2025",
        "alert": "Alert: Machine {machine} exceed the threshold value. Actual: {currentValue} Threshold: {valueThreshold}",
        “data:{
        "valueThreshold": 0,
        "currentValue": 0,
        "machineId": "machine1"}
    }
    """
    event_id: int
    event_type: str
    time: int
    time_hr: str
    alert: str
    data: dict