import os
import json
from logging import DEBUG, Logger
from fastapi import HTTPException, status
from langchain_core.prompts import PromptTemplate
from langchain_core.exceptions import OutputParserException

from imc.config import settings
from imc.modules.llms.llm import get_llm
from imc.modules.utils import custom_logs
from imc.api.plugins.models import PluginInfo
from langchain_community.tools import OpenAPISpec
from imc.modules.utils.crypto import EncryptDecrypt
from imc.modules.agents.openapi.utils import get_openapi_schema
from imc.modules.agents.openapi.CustomRequestChain import get_custom_openapi_chain

logger = custom_logs.getLogger(__name__, DEBUG)


class OpenApiAgent:
    def __init__(self, plugin: PluginInfo):
        self.logger: Logger = logger
        self.id = plugin.id
        self.title = plugin.title
        self.url = plugin.url
        self.schema_url = plugin.schema_url
        self.verify_ssl = plugin.verify_ssl
        self.prompt = plugin.prompt
        self.auth_type = plugin.auth_type
        self.auth_params = plugin.auth_params
        self.config_params = plugin.config_params
        self.llm = get_llm()

    def build_agent(self):
        self.logger.debug(f"{self.__class__.__name__}: Building agent.")

        secret_key = settings.encrypt_secret_key

        # Load and parse OpenAPI schema
        schema = self._load_openapi_schema()
        self.spec = OpenAPISpec.from_spec_dict(schema)

        # Set headers based on auth type
        self.headers = self._build_headers(secret_key)

        # Load optional config parameters
        self._load_config_params(secret_key)

        # Construct final prompt
        self._build_prompt_template()

        self.openapi_chain = self._build_chain()
        
    def ask_agent(self, question):
        self.logger.critical(f"{self.__class__.__name__}: Getting agent response.")
        max_retries = int(settings.max_retries_parser_error_func_call)
        attempts = 0
        while attempts < max_retries:
            try:
                response = [
                    self.openapi_chain.invoke(
                        {"question": question}
                    )
                ]
                self.logger.info(f"Raw chain output: {response}")
                return response

            except OutputParserException as e:
                print(e)
                attempts += 1
                if attempts == max_retries:
                    return []
                self.logger.warning(
                    f"Retrying {attempts}/{max_retries} times openapi_chain response because of Exception {e}... "
                )

            except Exception as e:
                self.logger.error(
                    f"{self.__class__.__name__}: An exception ocurred while querying the plugin: {e}"
                )
                return []
            
    def _load_openapi_schema(self):
        try:
            schema = get_openapi_schema(self.schema_url, self.url)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error while retrieving the schema: {e}",
            )
        return schema

    def _build_headers(self, secret_key):
        if self.auth_type == "bearer_token":
            decrypted = EncryptDecrypt.decrypt_secret_key(
                self.auth_params, secret_key=secret_key
            )
            parsed = json.loads(decrypted.replace("'", '"'))
            self.auth_token = parsed.get("bearer_token")
            return {
                "Authorization": f"Bearer {self.auth_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

        self.auth_token = None
        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _load_config_params(self, secret_key):
        self.parameters = {}

        if self.config_params:
            decrypted = EncryptDecrypt.decrypt_secret_key(
                self.config_params, secret_key=secret_key
            )
            if decrypted:
                self.parameters = json.loads(decrypted.replace("'", '"'))

    def _build_prompt_template(self):
        self.prompt_template = PromptTemplate(
            input_variables=["question"], template=self.prompt
        )

    def _build_chain(self):
        return get_custom_openapi_chain(
            self.spec,
            self.llm,
            verbose=True,
            headers=self.headers,
            params=self.parameters,
            verify_ssl=self.verify_ssl,
            prompt=self.prompt_template,
        )
