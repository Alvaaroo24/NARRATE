import requests
from openapi_spec_validator import openapi_v3_spec_validator
from openapi_spec_validator.validation.exceptions import OpenAPIValidationError
import yaml
import json


def _retrieve_schema(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        raw_content = response.text

        # Try to parse as JSON, then as YAML
        try:
            schema = json.loads(raw_content)
            openapi_v3_spec_validator.validate(schema)
        except json.JSONDecodeError:
            try:
                schema = yaml.safe_load(raw_content)
                openapi_v3_spec_validator.validate(schema)
            except yaml.YAMLError as e:
                raise ValueError(f"Failed to parse schema as JSON or YAML: {e}")
        return schema

    except requests.RequestException as e:
        raise requests.RequestException(f"Failed to fetch schema: {e}")
    except OpenAPIValidationError as e:
        raise OpenAPIValidationError(f"Schema validation failed: {e}")
    except ValueError as e:
        raise ValueError(f"Parsing error: {e}")


def _ensure_valid_url(manifest_url: str, plugin_url: str) -> str:
    """Ensure the URL starts with http(s)."""
    if manifest_url.startswith("http://") or manifest_url.startswith("https://"):
        return manifest_url
    return plugin_url


def _patch_schema(schema, server_url, converted=False):
    servers = schema.get("servers", [])
    if not servers or "url" not in servers[0]:
        raise ValueError("No valid server URL found in schema.")
    if converted:
        servers[0]["url"] = _ensure_valid_url(servers[0]["url"], server_url)
    else:
        servers[0]["url"] = server_url
    return schema

def _convert_swagger_to_openapi3(swagger_url: str):
    """
    Downloads a Swagger 2.0 spec ignoring SSL errors and converts it to OpenAPI 3.0.
    """
    raw_response = requests.get(swagger_url, verify=False)
    if raw_response.status_code != 200:
        raise Exception(f"Failed to download Swagger file: {raw_response.status_code}")

    swagger_spec = raw_response.json()

    api_url = "https://converter.swagger.io/api/convert"
    headers = {"Accept": "application/json"}
    response = requests.post(api_url, headers=headers, json=swagger_spec)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(
            f"Conversion failed with status code {response.status_code}: {response.text}"
        )


def get_openapi_schema(schema_url: str, server_url: str):
    raw_schema = _retrieve_schema(schema_url)
    try:
        schema = _patch_schema(raw_schema, server_url)
        openapi_v3_spec_validator.validate(schema)
        return schema
    except Exception as e:
        print("OpenApi v3 failed, attempting conversion...")
        try:
            converted_schema = _convert_swagger_to_openapi3(raw_schema)
            schema = _patch_schema(converted_schema, server_url)
            openapi_v3_spec_validator.validate(schema)
            return schema
        except Exception as e:
            print(f"Failed to load or process OpenAPI schema: {e}")
