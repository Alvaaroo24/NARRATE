import json
from typing import List
from langchain.agents import Tool
from imc.api.plugins.models import PluginInfo
from imc.modules.agents.openapi.module import OpenApiAgent
# from imc.modules.agents.rag_mock.module import query_chroma_rag

#for testing purposes
from imc.modules.mocks.plugin import mock_plugin

agent = OpenApiAgent(plugin=mock_plugin)
agent.build_agent()

blueprint_tool = Tool(
    name="API_blueprint",
    description=(
        "Provides data related to the blueprint graph DB. Contains the database models an end-to-end manufacturing and supply chain knowledge graph for production, orderes by a retailer, manufacture by a lead producer, and tracking through all production stages — from raw materials and components to final assembly and quality control. "
    ),
    func=lambda question: agent.ask_agent(question)
)

# rag_rool = Tool(
#     name="RAG_Tool",
#     description=("Provides data about maintenances for the machines."),
#     func=lambda question: str(query_chroma_rag(question)) or "No results"
# )