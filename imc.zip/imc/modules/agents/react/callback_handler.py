
from langchain.callbacks.base import BaseCallbackHandler

class ReActCallbackHandler(BaseCallbackHandler):
    def __init__(self, storage_list):
        self.storage = storage_list

    def on_chain_start(self, serialized, inputs, **kwargs):
        self.storage.append({"event": "chain_start", "serialized": serialized, "inputs": inputs})

    def on_chain_end(self, outputs, **kwargs):
        self.storage.append({"event": "chain_end", "outputs": outputs})

    def on_tool_start(self, serialized, input_str, **kwargs):
        self.storage.append({"event": "tool_start", "tool": serialized.get('name'), "input": input_str})

    def on_tool_end(self, output, **kwargs):
        self.storage.append({"event": "tool_end", "output": output})

    def on_text(self, text, **kwargs):
        # captures intermediate reasoning steps ("Thought:", "Action:")
        self.storage.append({"event": "text", "text": text})

    def on_llm_end(self, response, **kwargs):
        self.storage.append({"event": "llm_end", "response": response})