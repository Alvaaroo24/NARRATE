import os
from logging import DEBUG, Logger

from langchain_core.exceptions import OutputParserException
from langchain_experimental.plan_and_execute import (
    PlanAndExecute,
    load_chat_planner,
    load_agent_executor,
)

from imc.config import settings
from imc.modules.llms.llm import get_llm
from imc.modules.utils import custom_logs
from imc.modules.agents.react.tools import blueprint_tool
from imc.modules.agents.react.models import ReActAgentResponse, StepModel
from imc.modules.agents.utils.models import ContextModel, ResponseModel
from imc.modules.agents.react.callback_handler import ReActCallbackHandler
from imc.modules.agents.react.prompts import base_prompt, default_plan_template

logger = custom_logs.getLogger(__name__, DEBUG)


class ReActAgent:

    def __init__(
        self,
        question: str,
        plan_prompt: str = None,
        criteria_prompt: str = None,
        history: str = None,
    ):
        self.logger: Logger = logger

        self.question = question
        self.plan_prompt = plan_prompt
        self.criteria_prompt = criteria_prompt
        self.tools = [blueprint_tool]
        self.llm = get_llm()
        self.plan_actions = []
        self.history = history

    def build_agent(self):
        if not self.plan_prompt:
            self.plan_prompt = default_plan_template
        self.final_prompt = self._build_react_prompt(
            self.plan_prompt, self.criteria_prompt, self.history
        )
        self.planner = load_chat_planner(self.llm, self.final_prompt)
        self.executor = load_agent_executor(tools=self.tools, llm=self.llm)
        self.react_chain = PlanAndExecute(planner=self.planner, executor=self.executor)
        self.logger.info("Successfully build ReAct agent")

    def plan_and_execute(self):
        self.logger.info(f"{self.__class__.__name__}: Getting agent response.")
        max_retries = int(settings.max_retries_parser_error_func_call)
        attempts = 0

        callback_handler = ReActCallbackHandler(self.plan_actions)

        while attempts < max_retries:
            try:

                result = [
                    self.react_chain.invoke(
                        {"input": f"Use the available tools to generate a response: {self.question}"},
                        config={"callbacks": [callback_handler]},
                    )
                ]

                self.logger.info(result)
                return ResponseModel(
                    question=self.question,
                    answer=result,
                    context=ContextModel(
                        reasoning_steps=[StepModel(**step) for step in self.plan_actions],
                        success=True
                    )
                )

            except OutputParserException as e:
                attempts += 1
                if attempts == max_retries:
                    return ResponseModel(
                        question=self.question,
                        answer=None,
                        context=ContextModel(
                            reasoning_steps=[
                                StepModel(**step) for step in self.plan_actions
                            ],
                            success=False,
                            error_message=str(e)
                        )
                    )
                
                self.logger.warning(
                    f"Retrying {attempts}/{max_retries} times openapi_chain response because of Exception {e}... "
                )

            except Exception as e:
                self.logger.error(
                    f"{self.__class__.__name__}: An exception ocurred: {e}"
                )
                import traceback
                self.logger.error(f"Exception type: {type(e)}")
                self.logger.error(traceback.format_exc())
                raise
            
    def _build_react_prompt(self, plan: str, criteria: str, history: str):
        final_prompt = (
            base_prompt.replace("__PLAN__", plan)
            .replace("__CRITERIA__", criteria)
            .replace("__HISTORY__", history)
        )
        return final_prompt
