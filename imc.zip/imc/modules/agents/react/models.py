from typing import List, Optional, Any
from pydantic import BaseModel, Field

class StepModel(BaseModel):
    """Represents one event or reasoning step during execution."""
    event: str = Field(..., description="Type of event, e.g. 'tool_start', 'tool_end', 'text', etc.")
    text: Optional[str] = Field(None, description="Raw text output (for reasoning steps).")
    tool: Optional[str] = Field(None, description="Tool name if applicable.")
    input: Optional[Any] = Field(None, description="Input sent to the tool or model.")
    output: Optional[Any] = Field(None, description="Output or observation from the tool or model.")
    response: Optional[Any] = Field(None, description="LLM full response object (if available).")
    serialized: Optional[Any] = Field(None, description="Serialized LangChain component data.")
    inputs: Optional[Any] = Field(None, description="Chain inputs at start.")
    outputs: Optional[Any] = Field(None, description="Chain outputs at end.")


class ReActAgentResponse(BaseModel):
    """Structured response containing both final output and reasoning steps."""
    question: str = Field(..., description="The input question to the agent.")
    final_response: Optional[Any] = Field(None, description="The final answer returned by the agent.")
    reasoning_steps: List[StepModel] = Field(..., description="List of all reasoning and tool steps taken by the agent.")
    success: bool = Field(..., description="Whether the execution completed successfully.")
    error_message: Optional[str] = Field(None, description="Any error that occurred during execution.")
