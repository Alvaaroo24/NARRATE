from sqlalchemy.ext.asyncio import AsyncSession
import json
from typing import List, Any
from imc.modules.data_managers.chat_manager import ChatManagerBase
from imc.modules.data_managers.plan_manager import PlanManagerBase
from imc.modules.data_managers.rules_manager import RulesManagerBase
from imc.modules.events.models import EventModel
from imc.modules.agents.utils.models import QueryResponse
from imc.modules.agents.react.module import ReActAgent
from imc.modules.llms.llm import get_llm
from langchain_core.prompts import PromptTemplate
from imc.modules.agents.rag_mock.module import query_chroma_rag

# For testing purposes
from imc.modules.mocks.plans import mock_plan_case_1, mock_plan_case_2


class OrchestratorAgent:
    def __init__(
        self,
        chat_manager: ChatManagerBase,
        plan_manager: PlanManagerBase,
        rules_manager: RulesManagerBase,
    ):
        self.chat_manager = chat_manager
        self.plan_manager = plan_manager
        self.rules_manager = rules_manager
        self.llm = get_llm()

    async def get_response(self, event: EventModel, db: AsyncSession) -> QueryResponse:
        """ """
        # possible_plans = await self.plan_manager.get_plans(db)
        # plan = None
        # # if possible_plans:
        # #     plan = self._select_plan(possible_plans)

        plan, decision = await self._select_plan(
            [mock_plan_case_1, mock_plan_case_2], event
        )

        rules = await self.rules_manager.get_rules(db)

        history = await self.chat_manager.get_history(
            event.chat_id, event.message_id, db
        )

        # Testing without condition, just providing all tools always.
        # if event.event_type == "chat_query":
        if decision == "1":
            react_agent = ReActAgent(
                question=event.query,
                plan_prompt=plan,
                criteria_prompt=rules,
                history=history,
            )
            react_agent.build_agent()
            response = react_agent.plan_and_execute()

        if decision == "2":
            response = query_chroma_rag(event.query)

        await self.chat_manager.add_message(
            chat_id=event.chat_id,
            message_id=event.message_id,
            message={"user": event.query, "system": response},
            db=db
        )
        return QueryResponse(response=response)

    async def _select_plan(
        self, possible_plans: List[str], event: Any
    ) -> tuple[str, str]:
        """
        Use an LLM to select the most appropriate plan given the user's query.
        If Plan 1 is selected, inject schema.json into it before returning.
        """
        if not possible_plans:
            raise ValueError("No plans available to select from.")

        user_query = event.query

        template = f"""
        You are an expert orchestrator that decides which execution plan best fits a user's question.

        Here are the available plans:

        PLAN 1:
        {possible_plans[0]}

        PLAN 2:
        {possible_plans[1]}

        User's question:
        "{user_query}"

        Decide which plan (1 or 2) is most appropriate for handling this question.
        Respond ONLY with "1" or "2".
        """

        prompt = PromptTemplate(template=template)

        try:
            result = await (prompt | self.llm).ainvoke({})
            decision = result.content.strip() if result else ""
        except Exception as e:
            print(f"Plan selection failed via LLM: {e}")
            decision = ""

        # Fallback if LLM output is unclear
        if decision not in {"1", "2"}:
            decision = "2" if "machine" in user_query.lower() else "1"

        selected_plan = possible_plans[int(decision) - 1]

        # Only inject schema if Plan 1 was selected
        if decision == "1":
            with open(
                "imc/modules/agents/orchestrator/schema.json", "r", encoding="utf-8"
            ) as file:
                data = json.load(file)
            json_string = json.dumps(data)
            selected_plan = selected_plan.replace("__SCHEMA__", json_string)

        return selected_plan, decision
