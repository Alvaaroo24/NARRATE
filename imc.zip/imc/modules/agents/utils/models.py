from typing import List, Optional, Any
from pydantic import BaseModel, Field

from imc.modules.agents.react.models import StepModel


class ContextModel(BaseModel):
    reasoning_steps: Optional[List[StepModel]] = Field(None, description="List of all reasoning and tool steps taken by the agent.")
    success: Optional[bool] = Field(None, description="Whether the execution completed successfully.")
    error_message: Optional[str] = Field(None, description="Any error that occurred during execution.")
    context_documents: Optional[List[Any]] = Field(None, description="List of context documents used to form the answer.")

# class ContextModel(BaseModel):
#     model_config = {"arbitrary_types_allowed": True}

#     reasoning_steps: Optional[List[StepModel]] = None
#     success: Optional[bool] = None
#     error_message: Optional[str] = None
#     context_documents: Optional[List[Any]] = None


class ResponseModel(BaseModel):
    question: str = Field(..., description="The input question to the agent.")
    answer: Optional[Any] = Field(None, description="The final answer returned by the agent.")
    context: ContextModel

# class ResponseModel(BaseModel):
#     model_config = {"arbitrary_types_allowed": True}

#     question: str
#     answer: Optional[Any] = None
#     context: Optional[ContextModel] = None



class QueryResponse(BaseModel):
    response: Any