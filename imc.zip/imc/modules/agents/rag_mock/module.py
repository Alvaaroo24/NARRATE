from langchain.chains import create_retrieval_chain
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.chains.combine_documents import create_stuff_documents_chain
from imc.config import settings
from imc.modules.llms.llm import get_llm
from langchain_core.prompts import ChatPromptTemplate
# from imc.modules.agents.rag_mock.models import ResponseModel
from imc.modules.agents.utils.models import ResponseModel, ContextModel

def query_chroma_rag(question: str):
    """Query an existing Chroma DB using Azure Chat and embeddings."""

    embeddings = AzureOpenAIEmbeddings(
        api_key=settings.azure_openai_api_key,
        azure_endpoint=settings.azure_openai_base_url,
        azure_deployment=settings.azure_openai_embbeding_model_deployment_name,
        openai_api_version=settings.azure_openai_api_version
    )

    vectordb = Chroma(
        persist_directory="imc/databases/chroma_mock",
        embedding_function=embeddings
    )
    retriever = vectordb.as_retriever(search_kwargs={"k": 3})
    llm = get_llm()
    
    prompt = ChatPromptTemplate.from_template(
    """You are an intelligent assistant helping answer user questions based on the provided context.
    
    Context:
    {context}
    
    Question:
    {input}
    
    Provide a clear and concise answer based only on the context above. 
    If the context does not contain enough information, say you don't know.
    """
    )

    combine_chain = create_stuff_documents_chain(llm, prompt)
    rag_chain = create_retrieval_chain(retriever, combine_chain)

    result = rag_chain.invoke({"input": question})
    print("Answer:\n", result["answer"])
    print("Context:")
    for d in result.get("context", []):
        print("-", d.page_content[:200], "...\n")

    return ResponseModel(
        question=question,
        answer=result["answer"],
        context=ContextModel(
            context_documents=result["context"]
        )
    )