from abc import ABC, abstractmethod
from typing import List

from sqlalchemy.ext.asyncio import AsyncSession


class PlanManagerBase(ABC):
    @abstractmethod
    async def get_plans(self, db: AsyncSession) -> List[str]:
        pass

    @abstractmethod
    async def save_plan(self, db:AsyncSession, plan):
        pass


class PlanManager(PlanManagerBase):
    # TODO: Implement logic
    async def get_plans(self, db: AsyncSession):
        return ["Plan A", "Plan B"]
    
    async def save_plan(self, db, plan):
        pass