from abc import ABC, abstractmethod
from typing import List

from sqlalchemy.ext.asyncio import AsyncSession


class RulesManagerBase(ABC):
    @abstractmethod
    async def get_rules(self, db: AsyncSession) -> str:
        pass


class RulesManager(RulesManagerBase):
    # TODO: Implement logic
    async def get_rules(self, db: AsyncSession):
        return "Rules placeholder"