from abc import ABC, abstractmethod
from typing import List

from sqlalchemy.ext.asyncio import AsyncSession


class ChatManagerBase(ABC):
    @abstractmethod
    async def get_history(self, chat_id: int, message_id: int, db: AsyncSession) -> str:
        pass

    @abstractmethod
    async def add_message(self, chat_id: int, message_id: int, message: dict, db:AsyncSession):
        pass


class ChatManager(ChatManagerBase):
    # TODO: Implement logic
    async def get_history(self, chat_id: int, message_id: int, db: AsyncSession):
        return "history placeholder"

    async def add_message(self, chat_id: int, message_id: int, message: dict, db:AsyncSession):
        pass