import contextlib

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from contextlib import asynccontextmanager

from imc.config import settings

from imc.modules.utils import custom_logs

logger = custom_logs.getLogger(__name__)


engine = create_async_engine(
    settings.database_url,
    echo=False,
    future=True,
)


async_session_maker: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine,
    autoflush=False,
    expire_on_commit=False,
)

@asynccontextmanager
async def get_db():
    async with async_session_maker() as session:
        try:
            yield session
        finally:
            await session.close()
