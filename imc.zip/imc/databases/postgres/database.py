import os

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from imc.config import settings

# database_name = os.getenv("POSTGRES_BDNAME")
# database_user = os.getenv("POSTGRES_USER")
# database_password = os.getenv("POSTGRES_PASSWORD")
# database_host = os.getenv("POSTGRES_HOST")
# database_port = os.getenv("POSTGRES_PORT")

# sqlalchemy_database_url = f"postgresql://{database_user}:{database_password}@{database_host}:{database_port}/{database_name}"
# if not sqlalchemy_database_url:
#     raise RuntimeError(
#         "Error creating database engine: SQLALCHEMY_DATABASE_URI is not set"
#     )


engine = create_engine(settings.database_url)


SessionLocal: sessionmaker[Session] = sessionmaker(
    autocommit=False, autoflush=False, bind=engine
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()